# REF-001: Stellar Tables

**Reference Document for:** [Mneme-CE-World-Generator-FRD.md](../Mneme-CE-World-Generator-FRD.md)  
**Section:** 5.1 Primary Star Generation  
**Last Updated:** 2026-04-09

---

## Table 1: Stellar Class (5D6)

Determines the spectral class of the star.

| 5D6 Result | Class | Color | Description |
|------------|-------|-------|-------------|
| ≥30 | O | Blue White | Hottest, most massive |
| 29-28 | B | Deep Blue White | Very hot, very massive |
| 27-26 | A | Blue White | Hot, white |
| 25-24 | F | White | Yellowish white |
| 23-22 | G | Yellow | Yellowish white (Sun-like) |
| 21-20 | K | Orange | Pale yellow orange |
| ≤19 | M | Red | Light orange red, coolest |

**Class Rank (for companion constraints):** O=7, B=6, A=5, F=4, G=3, K=2, M=1

---

## Table 2: Stellar Grade (5D6)

Determines the luminosity grade within the spectral class. Lower grade = more luminous.

| 5D6 Result | Grade | Luminosity |
|------------|-------|------------|
| 5-17 | 9 | Least luminous in class |
| 18-20 | 8 | |
| 21-22 | 7 | |
| 23-24 | 6 | |
| 25 | 5 | |
| 26 | 4 | |
| 27 | 3 | |
| 28 | 2 | |
| 29 | 1 | |
| 30 | 0 | Most luminous in class |

---

## Table 3: Stellar Mass (by Class and Grade)

Mass in Solar Masses (M☉).

| Class | Grade 0 | Grade 1 | Grade 2 | Grade 3 | Grade 4 | Grade 5 | Grade 6 | Grade 7 | Grade 8 | Grade 9 |
|-------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|
| O | 90.0 | 75.0 | 60.0 | 45.0 | 35.0 | 25.0 | 20.0 | 17.5 | 15.0 | 13.0 |
| B | 16.0 | 14.0 | 12.0 | 10.0 | 8.5 | 7.0 | 6.0 | 5.0 | 4.5 | 4.0 |
| A | 3.5 | 3.2 | 2.9 | 2.6 | 2.3 | 2.1 | 1.9 | 1.7 | 1.6 | 1.5 |
| F | 1.45 | 1.38 | 1.31 | 1.24 | 1.17 | 1.10 | 1.04 | 0.98 | 0.92 | 0.87 |
| G | 0.82 | 0.79 | 0.76 | 0.73 | 0.70 | 0.67 | 0.64 | 0.61 | 0.58 | 0.55 |
| K | 0.52 | 0.50 | 0.48 | 0.46 | 0.44 | 0.42 | 0.40 | 0.38 | 0.36 | 0.34 |
| M | 0.32 | 0.28 | 0.25 | 0.22 | 0.19 | 0.16 | 0.14 | 0.12 | 0.10 | 0.08 |

---

## Table 4: Stellar Luminosity (by Class and Grade)

Luminosity in Solar Luminosities (L☉).

| Class | Grade 0 | Grade 1 | Grade 2 | Grade 3 | Grade 4 | Grade 5 | Grade 6 | Grade 7 | Grade 8 | Grade 9 |
|-------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|
| O | 500,000 | 350,000 | 250,000 | 180,000 | 130,000 | 90,000 | 65,000 | 48,000 | 35,000 | 25,000 |
| B | 18,000 | 13,000 | 9,500 | 7,000 | 5,200 | 3,800 | 2,800 | 2,100 | 1,600 | 1,200 |
| A | 900 | 720 | 580 | 460 | 370 | 300 | 240 | 190 | 155 | 125 |
| F | 100 | 82 | 67 | 55 | 45 | 37 | 30 | 25 | 20 | 17 |
| G | 14 | 11.8 | 9.9 | 8.3 | 7.0 | 5.9 | 4.9 | 4.1 | 3.5 | 2.9 |
| K | 2.4 | 2.0 | 1.7 | 1.4 | 1.2 | 1.0 | 0.83 | 0.70 | 0.59 | 0.50 |
| M | 0.42 | 0.30 | 0.22 | 0.16 | 0.12 | 0.085 | 0.062 | 0.045 | 0.033 | 0.024 |

---

## Zone Boundary Calculation

Once luminosity is determined, calculate zone boundaries:

```
sqrtL = √L☉

Infernal Zone:           0 to <(sqrtL × 0.4)
Hot Zone:                (sqrtL × 0.4) to <(sqrtL × 0.8)
Conservative Habitable:  (sqrtL × 0.8) to <(sqrtL × 1.2)
Optimistic Habitable:    (sqrtL × 1.2) to <(sqrtL × 4.85)
Outer Solar System:      ≥(sqrtL × 4.85)
```

---

## Example: Sol (G2 Star)

- Class: G
- Grade: 2 (G2)
- Mass: 0.76 M☉
- Luminosity: 0.76 L☉
- √L☉ = 0.87

**Zone Boundaries:**
- Infernal: 0 to <0.35 AU
- Hot: 0.35 to <0.70 AU
- Conservative Habitable: 0.70 to <1.04 AU
- Optimistic Habitable: 1.04 to <4.22 AU
- Outer Solar System: ≥4.22 AU
